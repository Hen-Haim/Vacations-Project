let errorHandler = (err, req, res, next) => {
    if (err.errorType != undefined) {

        if (err.errorType.isShowStackTrace) {
            console.error("show me my error", err);
        }

        res.status(err.errorType.httpCode).json({ error: err.errorType.message });
        console.log(err.errorType.message)
        return;
    }

    console.error(err);
    res.status(700).json({ error: "General error" });
}

module.exports = errorHandler;