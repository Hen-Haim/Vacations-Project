import './App.css';
import Footer from './Components/AppArea/Footer/Footer';
import Header from './Components/AppArea/Header/Header';
import {BrowserRouter} from "react-router-dom";
import Main from './Components/AppArea/Main/Main';


function App() {
  const imgStyle = ()=>{
    return `url(${process.env.PUBLIC_URL + '/upload/background-photo.jpg'})`
  }
  return (
    <BrowserRouter>
      <div style={{backgroundImage: imgStyle()}} className="App">
      {/* <div className="App"> */}

        <header>
          <Header/>
        </header>

        <main>
          <Main/>
        </main>

        <footer>
          <Footer/>
        </footer>

      </div>
    </BrowserRouter>
  );
}

export default App;
