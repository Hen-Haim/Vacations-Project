import "./PopUpModal.css";
import {useEffect} from "react";
import {useSelector, RootStateOrAny} from "react-redux";


const PopUpModel = () => {
    let triggeringModal = useSelector((state:RootStateOrAny)=> state.triggeringModal);
    console.log(triggeringModal)

    useEffect(() => {
        if(triggeringModal===undefined){
            triggeringModal ='';
        }
    }, [triggeringModal])

    return (
    <div className="PopUpModal" >
        <div className = "modal fade" id = {`${triggeringModal?.title}`} tabIndex = {-1} aria-labelledby={`${triggeringModal?.title}-Label`} aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id = {`${triggeringModal?.title}-Label`}>{triggeringModal?.title}</h5>
                        <button type="button" className="btn-close btn-x" data-bs-dismiss="modal" aria-label="Close">
                            <i className="fas fa-times icon-x"></i>
                        </button>
                    </div>
                    <div className="modal-body">
                        {triggeringModal?.message}
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn pop-left-btn"
                            data-bs-dismiss="modal">{triggeringModal?.buttonLeftText}</button>
                        <button type="button" className="btn pop-right-btn" data-bs-dismiss="modal"
                            onClick={triggeringModal?.buttonRightFunc}>{triggeringModal?.buttonRightText}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    )
}

export default PopUpModel