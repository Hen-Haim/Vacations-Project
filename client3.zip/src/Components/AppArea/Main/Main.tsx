import {Route, Switch,Redirect} from "react-router-dom";
import Statistics from "../../MainArea/Statistics/Statistics";
import Home from '../../MainArea/Home/Home';
import AddingLocation from '../../MainArea/AddingLocation/AddingLocation';
import EditingLocation from '../../MainArea/EditingLocation/EditingLocation';
import Login from '../../MainArea/Login/Login';
import Register from '../../MainArea/Register/Register';
import RecentlyAdded from '../../MainArea/RecentlyAdded/RecentlyAdded';
import Search from '../../MainArea/Search/Search';
import Settings from '../../MainArea/Settings/Settings';
import TopFollowers from '../../MainArea/TopFollowers/TopFollowers';
import "./Main.css";
import PopUpModel from "./PopUpModal/PopUpModal";
import {useSelector, RootStateOrAny} from "react-redux";


const Main = () => {
    let isLogin:boolean;  
    let isAdmin:boolean;  
    let userDetails = useSelector((state:RootStateOrAny)=> state.restOfDetails);

    userDetails.isAdmin!==undefined ? isLogin = true : isLogin = false;
    userDetails.isAdmin ===1 ? isAdmin = true : isAdmin = false;
    return (
        <div className="Main">
            <Switch>
                <Route exact path="/home"><Home/></Route>
                <Route exact path="/login"><Login/></Route>
                <Route exact path="/register"><Register/></Route>
                {isLogin && 
                <>
                <Route exact path="/home/location/add"><AddingLocation/></Route>
                <Route exact path="/home/location/edit/:id"><EditingLocation/></Route>
                <Route exact path="/recently-added"><RecentlyAdded/></Route>
                <Route exact path="/search/:value"><Search/></Route>
                <Route exact path="/statistics"><Statistics/></Route>
                <Route exact path="/top-followers"><TopFollowers/></Route>
                </> 
                }
                {isAdmin &&
                <Route exact path="/settings"><Settings/></Route>
                }
                <Redirect from="/" to="/home" exact/>
                <Route><Home/></Route>                
            </Switch>
            <PopUpModel/>   
        </div>
    )
}

export default Main
