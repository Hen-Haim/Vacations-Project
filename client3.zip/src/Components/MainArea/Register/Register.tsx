import {UserModel,RestOfDetailsModel} from "../../../store/Models/UserModel";
import {Link,useHistory} from "react-router-dom";
import {useForm} from "react-hook-form";
import Axios from "axios";
import {login} from "../../../store/Actions/actions";
import "./Register.css";
import {useState, useRef} from 'react';
import {useDispatch} from "react-redux";
import {triggeringModal,logout} from "../../../store/Actions/actions";


const Register = () => {
    const {register, handleSubmit, formState: { errors }} = useForm<UserModel>();
    const history = useHistory();
    const dispatch = useDispatch();

    const loginFunc = async (data:UserModel) => {
        try{
            const result = await Axios.post<RestOfDetailsModel>(`http://localhost:3001/users/login`, data);
            dispatch(login(result.data));
            Axios.defaults.headers.common['Authorization'] = `Bearer ${result.data.token}`;
            localStorage.setItem("restOfDetails", JSON.stringify(result.data));
            history.push("/home");
        }catch(err){
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.err);        
        }
    }

    const submit = async (data: UserModel) => {
        try {
            await Axios.post<UserModel>("http://localhost:3001/users", data);
            const loginDetails = {userName:data.userName, password:data.password}
            loginFunc(loginDetails)
        } catch (err) {
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.err);
        }
    };

    const triggeringModalRef = useRef(null);
    const [dataBsToggle, setDataBsToggle] = useState<string>('');
    const [dataBsTarget, setDataBsTarget] = useState<string>('');

    const openModalForError = (msg : string) => {
        if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
            delete Axios.defaults.headers.common["Authorization"];
            dispatch(logout());
            localStorage.removeItem("restOfDetails");    
        }
        const errorMessage = {
            title : "Error-Message",
            message : `${msg}, would you like to refresh?`,
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(errorMessage));
        triggeringModalRef?.current?.click();
    }

    return (
        <div className="Register">
            <div className="register-main-content">
                <h3>Register
                    <i className="fas fa-user-plus users-icon"></i>
                </h3>
                <form className="form-submit" onSubmit={handleSubmit(submit)}>
                    <div className="form-groups">
                        {/* form group for userName */}
                        <div className="form-group">
                            <input 
                            {...register("userName", {required: true})} placeholder="Username:"/>
                            {errors.userName?<span className="err-msg">Missing Username</span>:<span className="no-err"></span>}
                        </div>
                        {/* form group for First Name */}
                        <div className="form-group">
                            <input 
                            {...register("firstName", {required: true})} placeholder="First Name:"/>
                            {errors.firstName?<span className="err-msg">Missing First Name</span>:<span className="no-err"></span>}
                        </div>
                        {/* form group for Last Name */}
                        <div className="form-group">
                            <input 
                            {...register("lastName", {required: true})} placeholder="Last Name:"/>
                            {errors.lastName?<span className="err-msg">Missing Last Name</span>:<span className="no-err"></span>}
                        </div>
                        {/* form group for Password */}
                        <div className="form-group">
                            <input
                            {...register("password", {required: true})} placeholder="Password:"/>
                            {errors.password?<span className="err-msg">Missing Password</span>:<span className="no-err"></span>}
                        </div>
                    </div>
                    <button type="submit"className="btn users-btn">Join Me</button>
                </form>
            </div>
            <div className="right-side-register">
                <div id="carouselExampleControls" className="carousel slide my-carousel" data-bs-ride="carousel">
                    <div className="carousel-inner my-carousel-inner">
                        <div className="carousel-item active">
                            <img src={process.env.PUBLIC_URL + '/upload/profile-pic.jpg'} alt="Profile-Pic" className="d-block w-100" />
                        </div>
                        <div className="carousel-item">
                            <img src={process.env.PUBLIC_URL + '/upload/profile-pic2.jpg'} alt="Profile-Pic" className="d-block w-100"/>
                        </div>
                        <div className="carousel-item">
                            <img src={process.env.PUBLIC_URL + '/upload/profile-pic3.jpg'} alt="Profile-Pic" className="d-block w-100" />
                        </div>
                        <div className="carousel-item">
                            <img src={process.env.PUBLIC_URL + '/upload/profile-pic4.jpg'} alt="Profile-Pic" className="d-block w-100" />
                        </div>
                    </div>
                </div>
                <h1>Come Join Me!</h1> 
                <h5>Already A User?</h5>
                <div className="form-buttons">
                    <Link to="/home" className="user-register">
                        <i className="fas fa-home user-register-icon"></i>
                        <p className="text-btn">Home</p> 
                    </Link>
                    <Link to="/login" className="user-register">
                        <i className="fas fa-sign-in-alt user-register-icon"></i>
                        <p className="text-btn">Login</p>
                    </Link>
                </div>            
            </div>
            <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
                data-bs-target={dataBsTarget} ref={triggeringModalRef}>
            </button> 
        </div>
    );
}

export default Register
