// import './Home.css';
// import Axios from "axios";
// import {LocationModel} from "../../../store/Models/LocationModel";
// import {useSelector, useDispatch, RootStateOrAny} from "react-redux";
// import LocationCard from "./LocationCard/LocationCard";
// import {useEffect,useState,useRef} from "react";
// import {login,getLocations, getUserLocations,logout, triggeringModal} from "../../../store/Actions/actions";
// import {useHistory} from "react-router-dom";



// const Home = () => {
//   let isLogin:boolean;  
//   let isAdmin:boolean;  
//   const dispatch = useDispatch();

//   let userDetails = useSelector((state:RootStateOrAny)=> state.restOfDetails);
//   const locations = useSelector((state:RootStateOrAny) => state.locations);
//   const history = useHistory();

//   userDetails.isAdmin!==undefined ? isLogin = true: isLogin=false;
//   userDetails.isAdmin ===1? isAdmin=true : isAdmin = false ;
//   const [hasError, setHasError] = useState(false);
//   // const buttonTriggeringModal = useRef(null);

//   const triggeringModalRef = useRef(null);
//   const [dataBsToggle, setDataBsToggle] = useState<string>('');
//   const [dataBsTarget, setDataBsTarget] = useState<string>('');

//   const openModalForError = (msg : string) => {
//     console.log(msg)
//     if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
//       delete Axios.defaults.headers.common["Authorization"];
//       dispatch(logout());
//       localStorage.removeItem("restOfDetails");
//       console.log(msg)   
//     } 
//     console.log(hasError)
//     console.log(msg)
//     console.log(triggerModalMessage)
//     // const errorMessage = {
//     //   title : "Error-Message",
//     //   message : `${msg}, would you like to refresh?`,
//     //   buttonRightText : "Yes", 
//     //   buttonLeftText : "No", 
//     //   buttonRightFunc : ()=>{
//     //     return(
//     //         history.push('/home'),
//     //         window.location.reload()
//     //     )
//     //   }
//     // }
//     // dispatch(triggeringModal(errorMessage));
//     // triggeringModalRef && triggeringModalRef?.current?.click();
//   }

//   const takingFromLocalStorage =()=>{
//     const userDetailsFromStorage = JSON.parse(localStorage.getItem("restOfDetails"));
//     Axios.defaults.headers.common['Authorization'] = `Bearer ${userDetailsFromStorage.token}`;
//     dispatch(login(userDetailsFromStorage));
//     allUserLocations();
//   } 
//   let triggerModalMessage = useSelector((state:RootStateOrAny)=> state.triggeringModal);



//   // const pageErrors = () => {
//   //   delete Axios.defaults.headers.common["Authorization"];
//   //   dispatch(logout());
//   //   localStorage.removeItem("restOfDetails");
//   //   setHasError(false);
//   // }
//   // hasError && pageErrors();

//   const allUserLocations = async () => {
//     try{
//       const result = await Axios.get<LocationModel[]>(`http://localhost:3001/locations/profile`);
//       dispatch(getUserLocations(result.data));
//     }catch(err){
//       setHasError(true);
//       allLocations();
//       // openModalForError(err.response?.data.error)
//       // setDataBsToggle("modal");
//       console.log("here")
//       // setDataBsTarget("#Error-Message");
//       openModalForError(err.response.data.error);
//     }
//   }
//   const allLocations = async() => {
//     try{
//       const result = await Axios.get<LocationModel[]>("http://localhost:3001/locations");
//       dispatch(getLocations(result.data)); 
//     }catch(err){
//       setHasError(true);
//       console.log(hasError)
//       // openModalForError(err.response?.data.error)
//       console.log(err.response.data.error)
//       // setDataBsToggle("modal");
//       console.log("here")
//       // setDataBsTarget("#Error-Message");
//       const errorMessage = {
//         title : "Error-Message",
//         message : `${err.response?.data.error}, would you like to login?`,
//         buttonRightText : "Yes", 
//         buttonLeftText : "No", 
//         buttonRightFunc : ()=>{history.push('/login')}
//       }
//       dispatch(triggeringModal(errorMessage));
//       console.log(triggerModalMessage)
//       openModalForError(err.response.data.error);
//     }
//   }

//   useEffect(() => {
//     console.log("here yay")
//     if(localStorage.getItem('restOfDetails') !== null){
//       takingFromLocalStorage()
//     }else if(!isLogin ){
//       allLocations()
//     }
//   }, [])

//   useEffect(()=>{
//     console.log(hasError)
//     if(hasError){
//       console.log(triggerModalMessage)
//       console.log(triggeringModalRef)
//       triggeringModalRef && triggeringModalRef?.current?.click();
//     }
//     return ()=>{
//       setHasError(false)
//     }
//   }, [hasError])


//   return (
//     <div className="Home">
//       {isAdmin &&  
//       <div className="adding-vacation-div">
//         <button type="button" className="add-btn" onClick={()=>history.push("/home/location/add")}>
//               <i className="fas fa-plus "></i>
//         </button>
//         <h5>Add Vacation</h5>
//       </div>
//       }
//       <div className="location-cards">
//         {locations?.map((location:LocationModel,index:number) => 
//           {return(
//             <LocationCard key={index} locations={locations} location={location}/>
//           )}
//         )}        
//       </div>
//       <button type="button" className="error-btn" data-bs-toggle ="modal"
//         data-bs-target="#Error-Message" ref={triggeringModalRef}>
//       </button> 
//     </div>
//   );
// }

// export default Home

import './Home.css';
import Axios from "axios";
import {LocationModel} from "../../../store/Models/LocationModel";
import {useSelector, useDispatch, RootStateOrAny} from "react-redux";
import LocationCard from "./LocationCard/LocationCard";
import React, {useEffect,useState,useRef} from "react";
import {login,getLocations, getUserLocations,logout, triggeringModal} from "../../../store/Actions/actions";
import {useHistory} from "react-router-dom";


const Home:React.FC<any> = () => {
  let isLogin:boolean;  
  let isAdmin:boolean;  
  const dispatch = useDispatch();

  let userDetails = useSelector((state:RootStateOrAny)=> state.restOfDetails);
  const locations = useSelector((state:RootStateOrAny) => state.locations);
  const history = useHistory();

  userDetails.isAdmin!==undefined ? isLogin = true: isLogin=false;
  userDetails.isAdmin ===1? isAdmin=true : isAdmin = false ;
  const [hasError, setHasError] = useState(false);
  const buttonTriggeringModal = useRef(null);

  let dataBsTarget:string;

  const openModalForError = (msg:string) => {
    const error = {
      title:"Error-Message",
      message:`${msg}, would you like to login?`,
      buttonRightText : "Yes", 
      buttonLeftText : "No", 
      buttonRightFunc : ()=>history.push('/login'),
      isShowing:true
    }
    dispatch(triggeringModal(error));
    buttonTriggeringModal?.current?.click();
    dataBsTarget = "Error-Message"
  }

  const takingFromLocalStorage =()=>{
    const userDetailsFromStorage = JSON.parse(localStorage.getItem("restOfDetails"));
    Axios.defaults.headers.common['Authorization'] = `Bearer ${userDetailsFromStorage.token}`;
    dispatch(login(userDetailsFromStorage));
    allUserLocations();
  }    

  const pageErrors = () => {
    delete Axios.defaults.headers.common["Authorization"];
    dispatch(logout());
    localStorage.removeItem("restOfDetails");
    setHasError(false);
  }
  hasError && pageErrors();

  const allUserLocations = async () => {
    try{
      const result = await Axios.get<LocationModel[]>(`http://localhost:3001/locations/profile`);
      dispatch(getUserLocations(result.data));
    }catch(err){
      setHasError(true);
      allLocations();
      openModalForError(err.response?.data.error)
    }
  }
  const allLocations = async() => {
    try{
      const result = await Axios.get<LocationModel[]>("http://localhost:3001/locations");
      dispatch(getLocations(result.data)); 
    }catch(err){
      setHasError(true);
      openModalForError(err.response.data.error)
    }
  }

  useEffect(() => {
    if(localStorage.getItem('restOfDetails') !== null){
      takingFromLocalStorage()
    }else if(!isLogin ){
      allLocations()
    }
  }, [])

  return (
    <div className="Home">
      {isAdmin &&  
      <div className="adding-vacation-div">
        <button type="button" className="add-btn" onClick={()=>history.push("/home/location/add")}>
              <i className="fas fa-plus "></i>
        </button>
        <h4>Add Vacation</h4>
      </div>
      }
      <button type="button" className="error-btn" data-bs-toggle="modal" 
          data-bs-target={`${dataBsTarget}`} ref={buttonTriggeringModal}>
      </button> 
      <div className="location-cards">
        {locations?.map((location:LocationModel,index:number) => 
          {return(
            <LocationCard key={index} locations={locations} location={location}/>
          )}
        )}        
      </div>
    </div>
  );
}

export default Home

