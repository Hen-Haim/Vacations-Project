import "./LocationCard.css";
import {LocationModel} from "../../../../store/Models/LocationModel";
import React, {useState,useRef,useEffect} from 'react';
import {useSelector, useDispatch, RootStateOrAny} from "react-redux";
import {FollowerModel} from "../../../../store/Models/followersModel";
import Axios from "axios";
import {addFollower, deleteFollower, triggeringModal, deleteLocation, logout} from "../../../../store/Actions/actions";
import {useHistory} from "react-router-dom";


interface LocationCardProps {
    location: LocationModel;
    locations?:LocationModel[];
}

const LocationCard:React.FC<LocationCardProps> = ({locations, location}) => {
    let isLogin:boolean;  
    let isAdmin:boolean;  
    let userDetails = useSelector((state:RootStateOrAny)=> state.restOfDetails);
    const triggeringModalRef = useRef(null);

    const history = useHistory();
    const dispatch = useDispatch();
    userDetails.isAdmin!==undefined ? isLogin = true : isLogin = false;
    userDetails.isAdmin ===1 ? isAdmin = true : isAdmin = false;

    function toggleFollowButton(locationId:number|string) {
        location.userId ===1? removeFollow(locationId) : addFollow(locationId)
    }

    const [locationIdForDelete,setLocationIdForDelete] = useState<string|number>(location.id);
    const [dataBsToggle, setDataBsToggle] = useState<string>('');
    const [dataBsTarget, setDataBsTarget] = useState<string>('');

    const openModalForDelete = (idForDelete : number|string) => {
        const deleteMessage = {
            title : "DELETE",
            message : "Are You Sure You Want To Delete This Resort?",
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>removeLocation(idForDelete)
        }
        dispatch(triggeringModal(deleteMessage));
    }
    
    useEffect(() => {
        if(locationIdForDelete !== '' ){
            triggeringModalRef?.current?.click();
        }
        return () => {
            setLocationIdForDelete('')
        }
    }, [locationIdForDelete])

    const openModalForError = (msg : string) => {
        if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
            delete Axios.defaults.headers.common["Authorization"];
            dispatch(logout());
            localStorage.removeItem("restOfDetails");
        }
        const errorMessage = {
            title : "Error-Message",
            message : `${msg}, would you like to refresh?`,
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(errorMessage));
        triggeringModalRef?.current?.click();
    }

    const addFollow = async (locationId : number|string) =>{
        try{
            await Axios.post<FollowerModel>(`http://localhost:3001/followers3/${locationId}`);
            const IndexToDelete = locations.findIndex((location:LocationModel)=> location.id===locationId);
            //i need to rearrange the locations order
            locations[IndexToDelete].userId = 1;
            locations[IndexToDelete].numOfFollowers = +locations[IndexToDelete].numOfFollowers + 1;
            sortLocation()
            dispatch(addFollower(locations));
        }catch(err){
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.error);
        }
    }

    const removeFollow = async (locationId:number|string) =>{
        try{
            await Axios.delete<FollowerModel>(`http://localhost:3001/followers/${locationId}`);
            const IndexToDelete = locations.findIndex((location:LocationModel)=> location.id===locationId);
            locations[IndexToDelete].userId = 0;
            locations[IndexToDelete].numOfFollowers = +(locations[IndexToDelete].numOfFollowers) -1;
            sortLocation();
            dispatch(deleteFollower(locations));
        }catch(err){
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.error);
        }
    }
    const removeLocation = async (idForDelete : number | string) =>{
        try{
            let indexToDelete = locations.findIndex((location:LocationModel)=> +location.id === +idForDelete);
            locations[indexToDelete].numOfFollowers = 0;
            const result = await Axios.delete<LocationModel>(`http://localhost:3001/locations/${idForDelete}`);
            //need somehow to print the result message for client
            locations.splice(indexToDelete, 1);
            dispatch(deleteLocation(locations));
        }catch(err){
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response?.data);
        } 
    };

    const sortLocation = ()=>{
        locations.sort((locationA:LocationModel, locationB:LocationModel)=>{
            return locationB.userId - locationA.userId || locationB.numOfFollowers - locationA.numOfFollowers 
        })
    }

    return (
        <div className="locations-item" key={location.id} style={{position: 'relative'}}>
            <div style={{display: location.userId===undefined? 'none' : 'flex'}}>
                {isLogin && !isAdmin &&
                <div className={location.userId===1? "hover-content" : 'follow-hover-content'}    
                    style={{display: location.userId===undefined? 'none' : 'flex'}}>
                    <button className={location.userId===1? 'unfollow-btn' : 'follow-btn'} 
                        onClick = {()=>toggleFollowButton(location.id)}>  
                        <i className={`fas fa-heart ${location.userId===1 ? "icon-heart": "icon-heart-filled"}`}></i> 
                    </button>                      
                </div>
                } 
                {isAdmin && 
                <div className="hover-content-admin">
                    <button className="edit-and-remove-btns" id={`${location.id}`} 
                        onClick={()=>history.push(`/home/location/edit/${location.id}`)}>
                        <i className="fas fa-edit"></i>
                    </button>
                    <button type="button" className="edit-and-remove-btns" id={`${location.id}`} 
                        onClick={(e:React.MouseEvent<HTMLButtonElement, MouseEvent>)=>{
                            return(
                                setDataBsToggle("modal"),
                                setDataBsTarget("#DELETE"),
                                openModalForDelete(e.currentTarget.id),
                                setLocationIdForDelete(e.currentTarget.id)
                            )}}>
                        <i className="far fa-trash-alt"></i>
                    </button> 
                </div>                       
                } 

            </div>
            <h3 >{location.resortName}</h3>
            <div className="resorts-image" >
                <img src={process.env.PUBLIC_URL + '/upload/resorts/' + location.image}/>
            </div>
            <h6 className="destination" style={{position: 'absolute',top:'170px',left:'6px'}}>
                {location.destination}
            </h6>
            <div className="dates-card">
                <h6>Start Date</h6>
                <h6>End Date</h6>
            </div>
            <div className="dates-card">
                <h6>{location.startDate}</h6>
                <h6>{location.endDate}</h6>
            </div>
            <div className="bottom-card">
                <button className="btn my-btn-description" type="button" data-bs-toggle="collapse" 
                    data-bs-target={`#${location.image.replace('.','-')}`} aria-expanded="false" 
                    aria-controls={`${location.image.replace('.','-')}`}>
                    <i className="fas fa-sort-down"></i>
                </button>
                <p className="price">{location.price}$</p>
                <span className="num-of-followers">{location.numOfFollowers}</span>
            </div>
            <div className="collapse" id={`${location.image.replace('.','-')}`}>
                <div className="card card-body my-collapse">
                    <p>{location.description}</p>                    
                </div>
            </div>
            <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
                    data-bs-target={dataBsTarget} ref={triggeringModalRef}>
            </button> 
        </div>
    );
};

export default LocationCard
