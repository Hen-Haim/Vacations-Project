import "./EditingLocation.css";
import {LocationModel} from "../../../store/Models/LocationModel";
import Axios from "axios";
import { useForm } from "react-hook-form";
import { Link, useHistory, useParams } from "react-router-dom";
import React, {useState,useRef,useEffect} from 'react';
import {useSelector, useDispatch, RootStateOrAny} from "react-redux";
import {triggeringModal, logout} from "../../../store/Actions/actions";


const EditingLocation = () => {
  const {register, handleSubmit, formState: { errors }} = useForm()
  const history = useHistory();
  const dispatch = useDispatch();

  let locations:LocationModel[]= useSelector((state: RootStateOrAny) => state.locations); 
  // console.log(locations) 
  const {id} = useParams<{ id: string }>();
  let locationIndex = locations.findIndex(location=> location.id ===+id);
  let location:LocationModel = locations[locationIndex];

  const triggeringModalRef = useRef(null);
  const [locationIdForDelete,setLocationIdForDelete] = useState<string|number>(location.id);
  const [dataBsToggle, setDataBsToggle] = useState<string>('');
  const [dataBsTarget, setDataBsTarget] = useState<string>('');

  const openModalForDelete = (idForDelete : number|string) => {
      const deleteMessage = {
          title : "DELETE",
          message : "Are You Sure You Want To Delete This Resort?",
          buttonRightText : "Yes", 
          buttonLeftText : "No", 
          buttonRightFunc : ()=>removeLocation(idForDelete)
      }
      dispatch(triggeringModal(deleteMessage));
  }
  
  useEffect(() => {
      if(locationIdForDelete !== '' ){
          triggeringModalRef?.current?.click();
      }
      return () => {
          setLocationIdForDelete('')
      }
  }, [locationIdForDelete])

  const openModalForError = (msg : string) => {
    if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
      delete Axios.defaults.headers.common["Authorization"];
      dispatch(logout());
      localStorage.removeItem("restOfDetails");    
    }
      const errorMessage = {
        title : "Error-Message",
        message : `${msg}, would you like to refresh?`,
        buttonRightText : "Yes", 
        buttonLeftText : "No", 
        buttonRightFunc : ()=>{
          return(
            history.push('/home'),
            window.location.reload()
          )
        }
      }
      dispatch(triggeringModal(errorMessage));
      triggeringModalRef?.current?.click();
  }

  const removeLocation = async (locationId:number|string) =>{
    try{
        await Axios.delete<LocationModel>(`http://localhost:3001/locations/${locationId}`);
        // need to see if we need dispatch to some request!!!!!!!!!!!!!!!!
        // dispatch(deleteLocation(result.data));
        //need to do a success for requests !!!!!!!!!!!!!!!!!!!!!!!
        history.push("/home");
    }catch(err){
      setDataBsToggle("modal");
      setDataBsTarget("#Error-Message");
      openModalForError(err.response.data.error);
    }
}

  const submit = async (data:LocationModel) => {
    try{
      data.resortName = location.resortName;
      await Axios.put<LocationModel>(`http://localhost:3001/locations/${id}`,data);
      history.push("/home");
    }catch(err){
      setDataBsToggle("modal");
      setDataBsTarget("#Error-Message");
      openModalForError(err.response.data.error);
    }
  }
  
  return (
    <div className="edit-location">
      <form className="editing-location-form" onSubmit={handleSubmit(submit)}>
        <div className="editing-location-main-content">
          <div className="form-groups-editing-location">
            <h6>Resort Name:</h6>    
            <h6>Destination:</h6>
            <h6>Description:</h6>
            <h6>Start Date:</h6>
            <h6>End Date:</h6>
            <h6>Image:</h6>
            <h6>Price:</h6>
          </div>
          <div className="form-groups-editing-location">
            {/* form group for resortName */}
            <div className="form-group-editing-location">
              <input 
                defaultValue={location.resortName}
                readOnly disabled
                {...register("resortName")} />
            </div>
            {/* form group for destination */}
            <div className="form-group-editing-location">
              <input 
              defaultValue={location.destination}
              {...register("destination", {required: true})} />
              {errors.destination ? <span className="err-msg">Missing Destination</span>:<span className="no-err"></span>}
            </div>
            {/* form group for description */}
            <div className="form-group-editing-location">
              <input 
              defaultValue={location.description}
              {...register("description", {required: true})} />
              {errors.description ? <span className="err-msg">Missing Description</span>:<span className="no-err"></span>}
            </div>
            {/* form group for Start Date */}
            <div className="form-group-editing-location">
              <input 
                defaultValue={location.startDate.split("/").reverse().join("-")}
              {...register("startDate", {required: true})} type="date"/>
              {errors.startDate ? <span className="err-msg">Missing Start Date</span>:<span className="no-err"></span>}
            </div>
            {/* form group End Date */}
            <div className="form-group-editing-location">
              <input 
              defaultValue={location.endDate.split("/").reverse().join("-")}
              {...register("endDate", {required: true})} type="date"/>
              {errors.endDate ? <span className="err-msg">Missing End Date</span>:<span className="no-err"></span>}
            </div>
            {/* form group image */}
            <div className="form-group-editing-location">
              <input 
              defaultValue={location.image}
              {...register("image", {required: true})} />
              {errors.image ? <span className="err-msg">Missing Image</span>:<span className="no-err"></span>}
            </div>
            {/* form group price */}
            <div className="form-group-editing-location">
              <input 
              defaultValue={location.price}
              {...register("price", {required: true})} type="number" min="1" max="999999"/>
              {errors.price ? <span className="err-msg">Missing Price</span>:<span className="no-err"></span>}
            </div>
          </div>
        </div>
          <button type="submit" className="btn editing-btn">
            <i className="fas fa-edit admin-editing-icon"></i>Update
          </button>
          {/* <button type="button" className="btn btn-danger btn-delete" data-bs-toggle="modal" 
            data-bs-target="#DELETE">
            <i className="far fa-trash-alt admin-deleting-icon"></i> Delete
          </button> */}
          <button type="button" className="btn btn-danger btn-delete" id={`${location.id}`} 
            onClick={(e:React.MouseEvent<HTMLButtonElement, MouseEvent>)=>{
              return(
                setDataBsToggle("modal"),
                setDataBsTarget("#DELETE"),
                openModalForDelete(e.currentTarget.id),
                setLocationIdForDelete(e.currentTarget.id)
              )}}>
            <i className="far fa-trash-alt admin-deleting-icon"></i>Delete
          </button> 
          {/* <PopUpModel 
            title="DELETE"
            message="Are You Sure You Want To Delete This Resort?"
            buttonRightText = "Yes"
            buttonLeftText = "No"
            buttonRightFunc = {()=>removeLocation(location.id)} 
            />  */}
        </form>
      <div className="right-side-editing-location" style={{backgroundImage: `url(${process.env.PUBLIC_URL + '/upload/resorts/' + location.image})`}}>
        <h1>Edit Location</h1>
        <div className="form-buttons-editing-location">
            <Link to="/home" className="admin-engaging-edit">
                <i className="fas fa-home admin-editing-icons"></i>
                <p className="text-btn">Home</p> 
            </Link> 
            <Link to="/home/location/add" className="admin-engaging-edit">
                <i className="fas fa-plus admin-editing-icons"></i>
                <p className="text-btn">Add</p> 
            </Link>                  
        </div> 
      </div>
      <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
        data-bs-target={dataBsTarget} ref={triggeringModalRef}>
      </button> 
    </div>
  );

}

export default EditingLocation
