import "./AddingLocation.css";
import {LocationModel} from "../../../store/Models/LocationModel";
import Axios from "axios";
import {Link, useHistory} from "react-router-dom";
import {useForm} from "react-hook-form";
import {useState,useRef} from 'react';
import {useDispatch} from "react-redux";
import {triggeringModal, logout} from "../../../store/Actions/actions";

const AddingLocation = () => {
    const {register, handleSubmit, formState: { errors }} = useForm<LocationModel>();
    let history = useHistory();
    const dispatch = useDispatch();

    const triggeringModalRef = useRef(null);
    const [dataBsToggle, setDataBsToggle] = useState<string>('');
    const [dataBsTarget, setDataBsTarget] = useState<string>('');


    const openModalForError = (msg : string) => {
        if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
            delete Axios.defaults.headers.common["Authorization"];
            dispatch(logout());
            localStorage.removeItem("restOfDetails");    
        }
        const errorMessage = {
            title : "Error-Message",
            message : `${msg}, would you like to refresh?`,
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(errorMessage));
        triggeringModalRef?.current?.click();
    }

    const submit = async (data: LocationModel) => {
        try {
            await Axios.post<LocationModel>("http://127.0.0.1:3001/locations", data);
            console.log(history);
            history.push("/home");
        } catch (err) {
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.err);
        }
    };

    return (
        <div className="add-location">
            <form className="adding-location-form" onSubmit={handleSubmit(submit)}>
                <div className="adding-location-main-content">
                    <div className="form-groups-adding-location">
                        <h6>Resort Name:</h6>    
                        <h6>Destination:</h6>
                        <h6>Description:</h6>
                        <h6>Start Date:</h6>
                        <h6>End Date:</h6>
                        <h6>Image:</h6>
                        <h6>Price:</h6>
                    </div>
                    <div className="form-groups-adding-location">
                        {/* form group for resortName */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("resortName", {required: true})} />
                        {errors.resortName? <span className="err-msg">Missing Resort Name</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group for destination */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("destination", {required: true})} />
                        {errors.destination? <span className="err-msg">Missing Destination</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group for description */}
                        <div className="form-group-adding-location">
                        <input  
                        {...register("description", {required: true})} />
                        {errors.description? <span className="err-msg">Missing Description</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group for Start Date */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("startDate", {required: true})} type="date"/>
                        {errors.startDate? <span className="err-msg">Missing Start Date</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group End Date */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("endDate", {required: true})} type="date"/>
                        {errors.endDate? <span className="err-msg">Missing End Date</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group image */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("image", {required: true})} />
                        {errors.image? <span className="err-msg">Missing Image</span>:<span className="no-err"></span>}
                        </div>

                        {/* form group price */}
                        <div className="form-group-adding-location">
                        <input 
                        {...register("price", {required: true})} type="number" min="1" max="999999"/>
                        {errors.price? <span className="err-msg">Missing Price</span>:<span className="no-err"></span>}
                        </div>
                    </div>  
                </div>
                <button className="btn adding-btn"><i className="fas fa-plus admin-adding-icon"></i>Add</button>
            </form>
            <div className="right-side-adding-location" style={{backgroundImage: `url(${process.env.PUBLIC_URL + '/upload/adding-location-pic.jpg'})`}}>
                <div className="right-side-adding">
                    <h1>A New Location</h1>
                    <div className="form-buttons-adding-location">
                        <Link to="/home" className="admin-engaging-add">
                            <i className="fas fa-home admin-to-add-icon"></i>
                            <p className="text-btn-home">Home</p> 
                        </Link>                
                    </div> 
                </div>
            </div>
            <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
                data-bs-target={dataBsTarget} ref={triggeringModalRef}>
            </button> 
        </div>
        );

}

export default AddingLocation
