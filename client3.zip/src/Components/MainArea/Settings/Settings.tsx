import {UserDetails} from "./UserDetails/UserDetails"
import "./Settings.css";
import {UserModel} from "../../../store/Models/UserModel";
import Axios from "axios";
import {deleteUser} from "../../../store/Actions/actions";
import {useHistory} from "react-router-dom";
import {useState,useRef} from 'react';
import {useDispatch} from "react-redux";
import {triggeringModal, logout} from "../../../store/Actions/actions";



const Settings = () => {
    const dispatch = useDispatch();
    const history = useHistory();

    const removeUser = async () =>{
        try{
            await Axios.delete<UserModel>(`http://localhost:3001/users`);
            delete Axios.defaults.headers.common["Authorization"];
            history.push("/home");
            dispatch(deleteUser());
            localStorage.removeItem("restOfDetails")
        }catch(err){
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.error);
        }
    }

    const triggeringModalRef = useRef(null);
    // const [locationIdForDelete,setLocationIdForDelete] = useState<string|number>(location.id);
    const [dataBsToggle, setDataBsToggle] = useState<string>('');
    const [dataBsTarget, setDataBsTarget] = useState<string>('');

    const openModalForDelete = () => {
        const deleteMessage = {
            title : "Delete-User",
            message : "Are You Sure You Want To Delete The Account?",
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>removeUser()
        }
        dispatch(triggeringModal(deleteMessage));
    }
    
    // useEffect(() => {
    //     if(locationIdForDelete !== '' ){
    //         triggeringModalRef?.current?.click();
    //     }
    //     return () => {
    //         setLocationIdForDelete('')
    //     }
    // }, [locationIdForDelete])

    const openModalForError = (msg : string) => {
            if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
                delete Axios.defaults.headers.common["Authorization"];
    dispatch(logout());
    localStorage.removeItem("restOfDetails");    
    }
        const errorMessage = {
            title : "Error-Message",
            message : `${msg}, would you like to refresh?`,
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(errorMessage));
        triggeringModalRef?.current?.click();
    }
    
    return (
        <div className="Settings" style={{backgroundImage: `url(${process.env.PUBLIC_URL + '/upload/editing-user-pic.jpg'})`}}>
            <UserDetails/>
            <div className="delete-user-div">
                <h6>To Delete This Account:</h6> 
                <button type="button" className="btn btn-danger btn-delete-user" data-bs-toggle="modal" 
                    data-bs-target="#Delete-User">
                    <i className="far fa-trash-alt user-deleting-icon"></i> Delete User
                </button>
                <button type="button" className="btn btn-danger btn-delete-user" onClick={()=>{
                    return(
                        setDataBsToggle("modal"),
                        setDataBsTarget("#Delete-User"),
                        openModalForDelete()
                    )}}>
                    <i className="far fa-trash-alt user-deleting-icon"></i>Delete User
                </button> 
                {/* <PopUpModal 
                    title="Delete-User"
                    message="Are You Sure You Want To Delete This User?"
                    buttonRightText = "Yes"
                    buttonLeftText = "No"
                    buttonRightFunc = {()=>removeUser()} 
                /> */}
            </div>
            <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
                data-bs-target={dataBsTarget} ref={triggeringModalRef}>
            </button> 
        </div>
    )
}

export default Settings
