import {useSelector, useDispatch, RootStateOrAny} from "react-redux";
import {UserModel} from "../../../../store/Models/UserModel";
import {getOneUser, updateUser} from "../../../../store/Actions/actions";
import {useForm} from "react-hook-form";
import "./UserDetails.css";
import Axios from "axios";
import { useHistory} from "react-router-dom";
import {useState, useRef, useEffect} from 'react';
import {triggeringModal, logout} from "../../../../store/Actions/actions";


export const UserDetails = () => {
    const dispatch = useDispatch();
    const {register, handleSubmit, formState: { errors }} = useForm()
    const history = useHistory();
    let user:UserModel = useSelector((state: RootStateOrAny) => state.user);
    // const [hasError, setHasError] = useState(false);
    // const [errorMessage, setErrorMessage] = useState('');
    // const [openModal, setOpenModal] = useState(false);

    useEffect(()=>{
        getUserDetails();
    },[])

    const getUserDetails= async()=>{
        try{
            const result = await Axios.get<UserModel>(`http://localhost:3001/users`);
            dispatch(getOneUser(result.data));
            console.log(result)
        } catch (err) {
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.err);
        }
    }

    // const pageErrors = ()=>{
    //     if(hasError){
    //         setHasError(false);
    //         console.log("this happens")
    //     }
    // }

    // useEffect(()=>{
    //     pageErrors()
    // },[hasError])

    const triggeringModalRef = useRef(null);
    // const [locationIdForDelete,setLocationIdForDelete] = useState<string|number>(location.id);
    const [dataBsToggle, setDataBsToggle] = useState<string>('');
    const [dataBsTarget, setDataBsTarget] = useState<string>('');

    // const openModalForDelete = (idForDelete : number|string) => {
    //     const deleteMessage = {
    //         title : "DELETE",
    //         message : "Are You Sure You Want To Delete This Resort?",
    //         buttonRightText : "Yes", 
    //         buttonLeftText : "No", 
    //         buttonRightFunc : ()=>removeLocation(idForDelete)
    //     }
    //     dispatch(triggeringModal(deleteMessage));
    // }
    
    // useEffect(() => {
    //     if(locationIdForDelete !== '' ){
    //         triggeringModalRef?.current?.click();
    //     }
    //     return () => {
    //         setLocationIdForDelete('')
    //     }
    // }, [locationIdForDelete])

    const openModalForError = (msg : string) => {
        if(msg === 'A Problem Occurred And You Are Currently Not Logged-In'){
            delete Axios.defaults.headers.common["Authorization"];
            dispatch(logout());
            localStorage.removeItem("restOfDetails");    
        }
        const errorMessage = {
            title : "Error-Message",
            message : `${msg}, would you like to refresh?`,
            buttonRightText : "Yes", 
            buttonLeftText : "No", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(errorMessage));
        triggeringModalRef?.current?.click();
    }

    const openModalForSuccess = (msg : string) => {
        const successMessage = {
            title : "Success-Message",
            message : `${msg}`,
            buttonRightText : "Ok", 
            buttonLeftText : "Close", 
            buttonRightFunc : ()=>{
                return(
                    history.push('/home'),
                    window.location.reload()
                )
            }
        }
        dispatch(triggeringModal(successMessage));
        triggeringModalRef?.current?.click();
    }

    const submit = async (data:UserModel) => {
        try{
            console.log(data)
            const result = await Axios.put<UserModel>(`http://localhost:3001/users`,data);
            //need to print the message that is in the result
            setDataBsToggle("modal");
            setDataBsTarget("#Success-Message");
            // openModalForSuccess(result.data);
            dispatch(updateUser([data]));
            history.push("/home");
        } catch (err) {
            setDataBsToggle("modal");
            setDataBsTarget("#Error-Message");
            openModalForError(err.response.data.error);
        }
    }
    console.log(user);

    return (
        <div className="edit-user" >
            <h3>Hello {user[0]?.userName}</h3>
            <form className="editing-location-form" onSubmit={handleSubmit(submit)}>
                <div className="editing-user-main-content">
                    <div className="form-groups-editing-user">
                        <h6>First Name:</h6>    
                        <h6>Last Name:</h6>
                        <h6>Password:</h6>
                    </div>
                    <div className="form-groups-editing-user">
                        <div className="form-group-editing-user">
                            <input 
                            defaultValue={user[0]?.firstName}
                            {...register("firstName", {required: true})} />
                            {errors.firstName ? <span className="err-msg">Missing First Name</span>:<span className="no-err"></span>}
                        </div>
                        <div className="form-group-editing-user">
                            <input 
                            defaultValue={user[0]?.lastName}
                            {...register("lastName", {required: true})} />
                            {errors.lastName ? <span className="err-msg">Missing Last Name</span>:<span className="no-err"></span>}
                        </div>
                        <div className="form-group-editing-user">
                            <input 
                            {...register("password", {required: true})} />
                            {errors.password ? <span className="err-msg">Missing Password</span>:<span className="no-err"></span>}
                        </div>
                    </div>
                </div>                    
                <button type="submit" className="btn editing-user-btn">
                    <i className="fas fa-edit user-editing-icon"></i>Update
                </button>
            </form>
            <button type="button" className="error-btn" data-bs-toggle ={dataBsToggle}
                data-bs-target={dataBsTarget} ref={triggeringModalRef}>
            </button> 
        </div>
    );
}


