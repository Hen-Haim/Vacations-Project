import {FollowerAction,FollowerActionType} from "../Models/followersModel";
import {UserModel,UsersActionType, UserAction, RestOfDetailsModel} from "../Models/UserModel";
import {LocationModel,LocationActionType, LocationAction} from "../Models/LocationModel";
import { popUpModel, popUpAction, popUpActionType } from "../Models/popUpModel";


export const addFollower = (locations:LocationModel[]):FollowerAction=>{
    return{
        type:FollowerActionType.ADD_FOLLOWER,
        payload:locations
    }
}

export const deleteFollower = (locations:LocationModel[]) : FollowerAction=>{
    return{
        type:FollowerActionType.DELETE_FOLLOWER,
        payload:locations
    }
}

export const login = (userDetails:RestOfDetailsModel)=>{
    return{
        type:UsersActionType.LOGIN_USER,
        payload:userDetails
    }
}

export const logout = () : UserAction=>{
    return{
        type:UsersActionType.LOGOUT_USER,
    }
}

export const getOneUser = (user:UserModel)=>{
    return{
        type:UsersActionType.GET_ONE_USER,
        payload:user
    }
}

export const deleteUser = () : UserAction=>{
    return{
        type:UsersActionType.DELETE_USER
    }
}

export const updateUser = (user:[UserModel]) : UserAction=>{
    return{
        type:UsersActionType.UPDATE_USER,
        payload:user
    }
}

export const getLocations = (locations:LocationModel[])=>{
    return{
        type:LocationActionType.GET_ALL_LOCATIONS,
        payload:locations
    }
}

export const getUserLocations = (locations:LocationModel[])=>{
    return{
        type:LocationActionType.GET_USER_LOCATIONS,
        payload:locations
    }
}

export const deleteLocation = (locations:LocationModel[]) : LocationAction=>{
    return{
        type:LocationActionType.DELETE_LOCATION,
        payload:locations
    }
}

export const triggeringModal = (modal:popUpModel) : popUpAction=>{
    return{
        type:popUpActionType.MODAL_MSG,
        payload:modal
    }
}
