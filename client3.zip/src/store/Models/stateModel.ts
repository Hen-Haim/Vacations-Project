import {UserModel} from "../Models/UserModel";
import { LocationModel } from "../Models/LocationModel"

export interface StateType{
    user:UserModel[],
    restOfDetails:{},
    locations:LocationModel[],
    modalMessage:{}
}