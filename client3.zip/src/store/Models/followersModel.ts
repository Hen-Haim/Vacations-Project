import {LocationModel} from "./LocationModel"

export class FollowerModel {
    public id: number;
    public userId: number;
    public locationId: number;
}

export enum FollowerActionType {
    ADD_FOLLOWER = "ADD_FOLLOWER",
    DELETE_FOLLOWER = "DELETE_FOLLOWER",
}

interface ADD_FOLLOWER{
    type: FollowerActionType.ADD_FOLLOWER,
    payload: LocationModel[]
}

interface DELETE_FOLLOWER{
    type: FollowerActionType.DELETE_FOLLOWER,
    payload: LocationModel[]
}

export type FollowerAction = ADD_FOLLOWER | DELETE_FOLLOWER 