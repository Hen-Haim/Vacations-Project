export class UserModel {
    public id?: number;
    public userName: string;
    public firstName?: string;
    public lastName?: string;
    public password: string;
    public isAdmin?: boolean;
}

export class RestOfDetailsModel {
    public token: string;
    public isAdmin: number;
    public userName: string;
}

export enum UsersActionType {
    LOGIN_USER="LOGIN_USER",
    GET_ONE_USER="GET_ONE_USER",
    DELETE_USER="DELETE_USER",
    UPDATE_USER="UPDATE_USER",
    LOGOUT_USER="LOGOUT_USER"
}

interface LOGIN_USER{
    type:UsersActionType.LOGIN_USER,
    payload: RestOfDetailsModel
}

interface GET_ONE_USER{
    type:UsersActionType.GET_ONE_USER,
    payload: [UserModel]
}

interface DELETE_USER{
    type: UsersActionType.DELETE_USER,
}

interface UPDATE_USER{
    type: UsersActionType.UPDATE_USER,
    payload: [UserModel]
}

interface LOGOUT_USER{
    type: UsersActionType.LOGOUT_USER,
}

export type UserAction = LOGIN_USER | GET_ONE_USER | DELETE_USER | UPDATE_USER | LOGOUT_USER