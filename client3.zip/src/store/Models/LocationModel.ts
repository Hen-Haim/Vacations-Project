export class LocationModel {
    public id: number;
    public resortName: string;
    public destination: string;
    public description: string;
    public startDate: string;
    public endDate: string;
    public image: string;
    public price: number;
    public userId?:number;
    public numOfFollowers?:number;
}

export enum LocationActionType {
    GET_ALL_LOCATIONS="GET_ALL_LOCATIONS",
    GET_USER_LOCATIONS="GET_USER_LOCATIONS",
    DELETE_LOCATION="DELETE_LOCATION",
    UPDATE_LOCATION="UPDATE_LOCATION",
    ADD_LOCATION="ADD_LOCATION",
}

export interface StateType{
    locations:LocationModel[],
}

interface GET_ALL_LOCATIONS{
    type:LocationActionType.GET_ALL_LOCATIONS,
    payload: LocationModel[]
}

interface GET_USER_LOCATIONS{
    type:LocationActionType.GET_USER_LOCATIONS,
    payload: LocationModel[]
}

interface DELETE_LOCATION{
    type: LocationActionType.DELETE_LOCATION,
    payload: LocationModel[]
}

interface UPDATE_LOCATION{
    type: LocationActionType.UPDATE_LOCATION,
    payload: LocationModel[]
}

interface ADD_LOCATION{
    type: LocationActionType.ADD_LOCATION,
    payload: LocationModel[]
}

export type LocationAction = DELETE_LOCATION | GET_ALL_LOCATIONS | GET_USER_LOCATIONS | UPDATE_LOCATION | ADD_LOCATION