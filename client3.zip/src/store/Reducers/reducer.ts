import {UsersActionType, UserAction} from "../Models/UserModel";
import {LocationAction, LocationActionType} from "../Models/LocationModel"
import {FollowerAction, FollowerActionType} from "../Models/followersModel";
import {popUpActionType, popUpAction} from "../Models/popUpModel";
import {StateType} from"../Models/stateModel";

let newState:StateType = { 
    user:[] ,
    restOfDetails:{},
    locations: [],
    modalMessage:{}
};
//user:[{isAdmin, username, firstname, lastname, password}]
//restOfDetails:{token, isAdmin, userName}

const reducer = (state:StateType =newState, action:UserAction|LocationAction|FollowerAction|popUpAction) =>{

    switch (action.type){
        case UsersActionType.LOGIN_USER:
            return {
                ...state,
                restOfDetails:{...action.payload},
            };
        case UsersActionType.GET_ONE_USER:
            return {
                ...state,
                user:[...action.payload],
            };
        case UsersActionType.DELETE_USER:
            return {
                ...state,
                locations:[],
                user:[],
                restOfDetails:[],
            };
        case UsersActionType.UPDATE_USER:
            return {
                ...state,
                user:[...action.payload],
            };
        case FollowerActionType.DELETE_FOLLOWER :
            return {
                ...state,
                locations:[...action.payload],
            };
        case FollowerActionType.ADD_FOLLOWER :
            return {
                ...state,
                locations:[...action.payload],
            };
        case LocationActionType.DELETE_LOCATION :
            return {
                ...state,
                locations:[...action.payload],
            };
        case LocationActionType.GET_ALL_LOCATIONS :
            return {
                ...state,
                locations:[...action.payload],
            };
        case LocationActionType.GET_USER_LOCATIONS :
            return {
                ...state,
                locations:[...action.payload],
            };
        case UsersActionType.LOGOUT_USER :
            return {
                ...state,
                locations:[],
                user:[],
                restOfDetails:[],
            };
        case popUpActionType.MODAL_MSG :
            return {
                ...state,
                modalMessage:{...action.payload},
            };
        default: return state;
    }
}
export default reducer